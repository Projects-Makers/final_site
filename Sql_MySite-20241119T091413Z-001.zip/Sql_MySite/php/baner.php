<header>
<div class="wypelniacz"><a href="index.php?strona=section">Strona Głowna</a><a href="#">Napis</a></div>

<div class="napis"><a href="index.php?strona=section">Podróż po Śląsku</a></div>

<div class="login">
   <a href="index.php?strona=login"><div class="sign-in-button">Sign in</div></a>
   <a href="index.php?strona-register"><div class="sign-up-button">Sign up</div></a>
</div>
</header>
