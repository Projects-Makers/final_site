<div class="profil-container">
<center>
<a href="index.php?strona=panel/edit-at"><div class="table">Atrakcje</div></a>
<a href="index.php?strona=panel/edit-mi"><div class="table">Miasta</div></a>
<a href="index.php?strona=panel/edit-rs"><div class="table">Restauracje</div></a>
</center>
</div>