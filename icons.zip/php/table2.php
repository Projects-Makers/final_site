<div class="profil-container">
<center>
<a href="index.php?strona=panel/remove-at"><div class="table">Atrakcje</div></a>
<a href="index.php?strona=panel/remove-mi"><div class="table">Miasta</div></a>
<a href="index.php?strona=panel/remove-rs"><div class="table">Restauracje</div></a>
</center>
</div>